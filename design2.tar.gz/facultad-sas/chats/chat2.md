# Design System Documentation

_Started 2026-05-25 16:49 UTC_

---

## User

podes darme un design.md? para poder entender y crear nuevas pantallas.

## Assistant

_[tool: list_files]_

_[tool: list_files]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: list_files]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

_[tool: read_file]_

Voy a leer el resto rápido y armar un `design.md` enfocado en el sistema (no en la pantalla específica) para que puedas crear nuevas pantallas con consistencia.

_[tool: write_file]_

Listo. Te dejé `design.md` en la raíz del proyecto.

A diferencia del README del handoff (que documenta la pantalla Plan de Estudios), este archivo está pensado para **crear pantallas nuevas**:

- **§1 Vibe** — la dirección visual en una página, con antipatrones explícitos.
- **§2 Tokens** — colores, tipografía, spacing, radius, sombras, bordes. Todo nombrado y con uso semántico (qué color para éxito, error, etc).
- **§3 Componentes** — recetas CSS listas para copiar: botones, chips, cards, tiles, progress, code chips, notas, status icons.
- **§4 Layouts** — estructura de página, grillas, breakpoints.
- **§5 Interacciones** — hover relacional, filtros (atenuar en vez de ocultar), transiciones.
- **§6 Iconografía** — convenciones de SVG inline.
- **§7 Checklist** — pasos para armar una pantalla nueva desde cero reusando `styles.css`.
- **§8 Roadmap** — pantallas candidatas que encajan en el lenguaje (detalle de materia, comisiones, historial, calendario de finales, dashboard, etc.).
- **§9 Cheat sheet** — tabla rápida de "quiero X → usá Y".

Cuando quieras armar una pantalla nueva, decime cuál y la construimos siguiendo la guía. Si encontrás que hace falta un componente que no está documentado, lo agregamos al `design.md` para que el sistema crezca consistente.

## User

ahora armemos una home simple, obivamente usando nuestras paleta de colores etc
esta es la que tengo actualmetne, si se te pocurren funcionalidades mejores o secciones agregalas.

## Assistant

_[tool: read_file]_

Dale, armemos una home cálida que matchea con el lenguaje papel/tinta de la malla. Voy a sumar algunas secciones útiles que faltaban en la versión dark: cuatrimestre actual, próximos eventos, materias listas para inscribirte y avisos.

_[tool: write_file]_

_[tool: write_file]_

_[tool: done]_

_[tool: fork_verifier_agent]_

Listo, te dejé `home.html` con el lenguaje papel/tinta de la malla. Lo que sumé respecto a tu versión dark:

**Estructura nueva:**
- **Sidebar** con navegación agrupada (Inicio · Plan de estudios · Cursadas · Finales · Inscripciones / Trámites: Constancias · Mensajes · Historial), avatar al pie y badges de contador.
- **Topbar** con breadcrumbs + búsqueda global + notificaciones (con dot de pendiente).
- **Hero** con saludo personal, fecha en eyebrow, y resumen humano: "Estás cursando 3 materias y tenés 2 finales esta semana".
- **Status summary** reutilizando el ring + 4 tiles del plan de estudios (con un cuarto bucket "Bloqueadas" que faltaba en tu versión).

**Secciones que no estaban en la dark y son útiles para una home:**
- **Tu cuatrimestre actual** — cards de materias en curso con próximo evento (parcial / TP) y un mini-CTA para entrar.
- **Próximos eventos** (sidebar derecha) — agenda con fecha grande tipo calendario impreso, chips por tipo (Final / Parcial / Trámite).
- **Listas para inscribirte** — recomendaciones del bucket "disponible" con CTA "Inscribirme" y conteo de comisiones.
- **Avisos** — comunicados de cátedra/secretaría/bedelía con dots de color por categoría y timestamp.

**Detalles del lenguaje cuidados:**
- Hard shadows (`2px 2px 0`, `3px 3px 0`) en todas las cards.
- Sidebar con gradiente sutil paper-2 → paper.
- Item activo del sidenav es bg tinta + sombra dura, igual que el botón primary.
- Calendario inline (día Fraunces grande + mes uppercase mono) en cada agenda-item.
- Aviso dot con halo `box-shadow` tintado.
- Hero title con el nombre en italic terracotta para el toque humano.

Si querés, próximo paso natural sería sumar a `design.md` el patrón **sidebar + main** y el componente **agenda-item** que inventamos acá, para que queden como vocabulario reutilizable. Decime y los documento.

## User

eliminemos avisos, y de la barra de la derecha eliminemos tramites/finales/incripciones deemos solo el home y el plan de estudios por ahora

## Assistant

_[tool: str_replace_edit]_

_[tool: done]_

Listo. Sidebar simplificada a **Inicio** + **Plan de estudios**, y la sección de **Avisos** eliminada del main. La home ahora tiene: hero · status summary · cuatri actual + agenda · listas para inscribirte. Más limpio.


# Handoff: Plan de Estudios (Malla Curricular)

## Overview

Vista interactiva de la malla curricular para un SaaS de gestión académica universitaria (Facultad SAS). Permite al alumno visualizar de un vistazo:

- Cuáles materias ya cursó / aprobó
- Cuáles está cursando o tiene a final
- Cuáles puede cursar (correlativas listas)
- Cuáles están bloqueadas y por qué (faltan correlativas)
- El flujo de correlatividad entre materias a lo largo de la carrera

La pantalla principal es una grilla horizontal donde cada **año académico** es un grupo, dentro del cual hay dos **sub-columnas** (1° y 2° cuatrimestre). Cada materia es una card. Las correlativas se dibujan como líneas curvas SVG entre cards.

## About the Design Files

Los archivos en este bundle son **referencias de diseño construidas en HTML/React** — prototipos que muestran la apariencia y el comportamiento previstos, **no código de producción para copiar tal cual**. La tarea es **recrear estos diseños en el entorno existente del codebase** (Next.js, Vite + React, Vue, etc.) usando los patrones, design system y librerías establecidas — o, si no hay aún un entorno, elegir el framework más adecuado e implementar allí.

El HTML/JSX entregado usa React 18 + Babel inline + CSS plano. En el codebase real esto debería traducirse a componentes idiomáticos (TSX con tipos, módulos CSS / Tailwind / styled-components según corresponda).

## Fidelity

**Alta fidelidad (hifi).** Colores, tipografías, spacing, estados de hover, animaciones, e interacciones están definitivos. El desarrollador debe replicar la UI pixel-perfect en las librerías del codebase. Las únicas decisiones abiertas son las de implementación técnica (animaciones con framer-motion vs CSS, estado con Zustand/Redux/Context, etc.).

---

## Estructura general

```
┌─────────────────────────────────────────────────────────────┐
│  TOPBAR  [logo+brand]   [student info]   [export · vista]   │
├─────────────────────────────────────────────────────────────┤
│  STATS ROW                                                  │
│  [Progress Ring + avg]  [Hechas | En curso | Disp | Block]  │
├─────────────────────────────────────────────────────────────┤
│  TOOLBAR  [filter chips por estado]      [search]           │
├─────────────────────────────────────────────────────────────┤
│  MALLA (scroll horizontal)                                  │
│    [Año 1 group][Año 2 group]...[Extras (Optativas+Anexo)]  │
│    Cada año: header con progreso + 2 sub-cols (C1 | C2)     │
│    SVG overlay con curvas bezier para correlativas          │
├─────────────────────────────────────────────────────────────┤
│  FOOTER  [legend buckets]                  [DNI · Nac]      │
└─────────────────────────────────────────────────────────────┘
```

---

## Screens / Views

### 1. Vista Malla (única vista actual)

**Propósito:** mostrar el plan completo en una sola pantalla scrolleable horizontalmente, con jerarquía visual clara entre estados.

#### Topbar (sticky)

- Altura: ~70px
- Grid: `minmax(220px, 280px) 1fr auto`, gap 32px, padding `18px 32px`
- Border-bottom: 1px sólido `--line-soft`
- Background: `rgba(239, 230, 211, 0.78)` + `backdrop-filter: blur(8px)`
- Position: sticky top 0, z-index 10

**Brand:**
- Mark: círculo 40×40px, border 1.5px `--ink`, box-shadow `2px 2px 0 --ink` (hard shadow, sin blur). Contiene un SVG: triángulo simple con dot en vértice superior (acento), dots negros en vértices inferiores.
- Name: `facultad·sas` — Fraunces italic 600 18px
- Sub: `PLAN DE ESTUDIOS` — Manrope 600 10.5px, letter-spacing 0.16em, uppercase, color `--ink-3`

**Student info:**
- Name (titleCase) — Fraunces 500 18px
- Meta row: `LU 1181713 · ING. EN INFORMÁTICA · Plan 1621` — Manrope 500 12px, color `--ink-3`. Separadores son dots 3×3px circulares `--ink-4`.

**Acciones:**
- "Exportar" (download icon + label) — botón con `--paper` bg, border `--line`, border-radius 999px, height 34px, padding 14px horizontal
- "Malla" (primary, indica vista activa) — bg `--ink`, color `--paper`, box-shadow `2px 2px 0 rgba(43,36,24,0.18)`

#### Stats Row

- Grid: `380px 1fr`, gap 14px, padding `22px 32px 6px`
- En viewport <1200px: stack a `1fr` (1 columna)

**Progress card (left):**
- Padding 18px 22px, bg `--paper`, border 1px `--line`, border-radius 12px, hard-shadow `3px 3px 0 --line-soft`
- Layout: flex row, gap 22px
- **ProgressRing:** SVG 92×92, stroke 8px. Track color `--bg-2`, fill un gradiente lineal `--st-promociona → --st-aprobado`. Texto centrado: `XX%` en Fraunces 600 18px.
- Meta:
  - Label: "PROGRESO DEL PLAN" — Manrope 700 10.5px, letter-spacing 0.16em, uppercase, `--ink-3`
  - Value: `<strong>16</strong> de 54 materias` — strong en Fraunces 600 30px `--ink`, resto Manrope 14px `--ink-2`
  - Linear progress bar: 6px tall, bg `--bg-2`, border 1px `--line-soft`, fill mismo gradiente. transition `width 0.6s cubic-bezier(.2,.8,.2,1)`
  - Avg row (separado por border-top dashed): "PROMEDIO 7.46 sobre 13 con nota". Avg value Fraunces 600 22px `--ink`.

**Stats tiles (right):**
- Grid: `repeat(4, 1fr)`, gap 12px (en <1200px: `repeat(2, 1fr)`)
- Cada tile: padding 16px 18px, bg `--paper`, border 1px `--line`, border-radius 12px, hard-shadow `3px 3px 0 --line-soft`. Tiene una barra vertical de 4px a la izquierda con el color de acento (`::after`).
- Label uppercase 10.5px `--ink-3` letter-spacing 0.16em
- Value Fraunces 600 32px `--ink`
- Sub Manrope 12px `--ink-3`

4 tiles fijas:
1. **Hechas** (accent `--st-aprobado`) — count aprobadas + sub "NNNN h cursadas"
2. **En curso** (accent `--st-inscripto`) — count (INSCRIPTO + A_FINAL + RECURSA) + sub "N cursando · N a final"
3. **Disponibles** (accent `--st-promociona`) — count pendientes con correlativas listas + sub "con correlativas listas"
4. **Bloqueadas** (accent `--st-pendiente`) — count pendientes bloqueadas + sub "falta cursar correlativas"

#### Toolbar

- Flex row, justify-content space-between, padding `14px 32px 18px`, flex-wrap

**Filter chips:**
- "Todas" + 7 estados (Promocionada, Aprobada, Equivalencia, Cursando, A final, Recursa, Pendiente)
- Chip: bg `--paper`, border 1px `--line`, border-radius 999px, padding `6px 13px 6px 11px`, font Manrope 600 12.5px, color `--ink-2`
- Dot 8×8px del color de estado, box-shadow 0 0 0 2px `--paper`, border 1px `rgba(43,36,24,0.2)`
- Count badge a la derecha: JetBrains Mono 11px 500 `--ink-3`
- Estado activo: bg `--ink`, color `--paper`, border `--ink`
- Toggle: cada chip toggleable; "Todas" limpia el filtro

**Search:**
- Pill input, height 34px, min-width 240px
- bg `--paper`, border 1px `--line`, border-radius 999px
- Search icon a la izquierda (lupa SVG 14×14, stroke currentColor `--ink-3`)
- Input: Manrope 500 13px `--ink`, placeholder `--ink-4`
- Buscar matching contra `m.nombre.toLowerCase().includes(q) || m.codigo.toLowerCase().includes(q)`

#### Malla (área principal)

- Container con `overflow-x: auto`, padding `4px 32px 32px`
- Scrollbar custom: 10px tall, thumb `--line-strong`, track transparent

**`malla-inner`** (contenido del scroll):
- Flex row, gap 0, width `max-content` (forzar ancho intrínseco)
- Padding-top 6px
- Position relative (para SVG absolute layer)

**Edges (SVG layer):**
- `<svg className="edges" ... position: absolute, inset: 0, pointer-events: none, z-index: 1>`
- Width = max(right) de todas las cards + 4
- Height = max(bottom) de todas las cards + 4
- Por cada materia con correlativas, una `<path>` cubic bezier desde el lado derecho de la correlativa hasta el lado izquierdo de la materia destino.
  - `d = M ${x1},${y1} C ${x1+dx},${y1} ${x2-dx},${y2} ${x2},${y2}`
  - `dx = max(|x2-x1| * 0.45, 60)`
  - Stroke color = color del estado de la materia destino (varía por status)
  - Stroke width: 1.6 default / 2.4 cuando activa (hover)
  - Opacity: 0.55 default, 1.0 cuando activa, 0.06 cuando dim
  - `<marker>` arrow al final, mismo color
  - Cuando activa: además se dibuja un `<circle r=3.5>` en el origen
- Recalcular posiciones con `ResizeObserver` sobre `malla-inner`, `window.resize`, y `document.fonts.ready`.

**Year Group (`.ygroup`):**
- Flex column, padding `0 8px`, position relative, z-index 2
- **Header (`.ygroup-head`):**
  - Flex row, gap 14px, padding `4px 6px 10px`
  - Border-bottom 1px `--line`, margin-bottom 14px
  - Title: chevron `▾` (12px `--ink-3`) + label "Primer año" Fraunces 600 18px `--ink`
  - Progress: barra horizontal 4px tall flex:1 + count `7/11` (JetBrains Mono 600 11px `--ink-2`)
- **Cols (`.ygroup-cols`):**
  - Grid `repeat(2, 232px)` gap 12px
  - Si solo 1 col (caso Extras con solo Optativas): `232px`

**SubColumn (`.subcol`):**
- Header: "1° CUATRIMESTRE" / "2° CUATRIMESTRE" — Manrope 700 10px uppercase letter-spacing 0.16em `--ink-3`, padding `0 4px 8px`, border-bottom 1px dashed `--line`, margin-bottom 10px
- Cards: flex column, gap 10px

**Card (`.card`):**
- Padding `10px 12px 11px`, bg `--paper`, border 1px `--line`, border-radius 10px
- Min-height 96px
- Hard shadow `2px 2px 0 --line-soft`
- Flex column gap 6px
- **Row 1 (`.card-row`):**
  - Status icon circle 22×22px, border-radius 50%, border 1.5px. Glyph SVG 11×11px adentro.
  - Short code: JetBrains Mono 600 10.5px, bg `--paper-3`, padding `2px 8px`, border-radius 6px, border 1px `--line-soft`
- **Nombre:** Fraunces 500 14px `--ink`, line-height 1.2, letter-spacing -0.005em, max 2 líneas (`-webkit-line-clamp: 2`), text-wrap balance
- **Footer (`.card-foot`):**
  - Meta a la izquierda: "Año X · CY · NNh" — Manrope 500 10.5px `--ink-3`. La parte `NNh` en JetBrains Mono `--ink-4`.
  - Nota a la derecha (solo si hay): Fraunces 600 14px del color del estado, padding `1px 9px 2px`, border-radius 8px, bg tinted, border tinted.

**Variantes por bucket:**

`bucketOf(m)` retorna uno de: `done`, `active`, `available`, `blocked`.

| Bucket | Status incluidos | Visual |
|--------|-----------------|--------|
| `done` | APROBADO, PROMOCIONA, EQUIV_INTERNA | Bg gradiente del color del estado (16% → 9% mezclado con paper), border `color-mix(--accent 44%, --line)`, status icon **filled** (bg accent, color paper), shadow tinted |
| `active` | INSCRIPTO, A_FINAL, RECURSA | Bg paper, border 1.5px del color del estado, status icon outlined (bg paper, border accent) |
| `available` | PENDIENTE sin correlativas faltantes | Bg paper, border `--line`, nombre `--ink-2`, status icon neutral (bg paper, border `--line`) |
| `blocked` | PENDIENTE con correlativas faltantes | Bg transparent, border 1px **dashed** `--line`, no shadow, opacity 0.74. Nombre `--ink-3` italic 400. Status icon lock (color `--ink-4`). Bajo el footer: pequeña meta "FALTA N CORRELATIVA(S)" en Manrope 700 10px uppercase `--ink-4`, con border-top dashed. |

**Status icons (SVG glyphs):**
- `done`: checkmark
- `active` (INSCRIPTO): dot relleno en el centro
- `active` (A_FINAL): signo de exclamación
- `active` (RECURSA): círculo con flecha (refresh)
- `available`: libro / dos páginas
- `blocked`: candado

**Estados de interacción (hover sobre una card):**
- Card hovered: border `--ink` solid 1px, bg `--paper-2`, hard shadow `4px 4px 0 --ink`, opacity 1
- Cards que son correlativas (prereqs) de la hovered: border `--st-afinal`, shadow tinted ámbar, opacity 1
- Cards que dependen de la hovered: border `--st-inscripto`, shadow tinted teal, opacity 1
- Resto de cards (`data-dim="1"`): opacity 0.32
- Líneas SVG: opacity 1 si involucran la hovered, 0.06 el resto; las relacionadas con stroke-width 2.4
- Transición: 0.15-0.2s ease

**Cards faded por filtro:** opacity 0.18 (más fuerte que dim — indica que no matchea el filtro/búsqueda activa).

#### Footer

- Border-top 1px `--line-soft`, padding `14px 32px 18px`
- Flex row space-between, flex-wrap, gap 20px

**Legend (4 swatches replicando el lenguaje de cada bucket):**
- `done`: cuadradito 14×14px, border-radius 4px, bg tinted con border, replicando done card
- `active`: cuadradito con borde grueso `--st-inscripto`
- `available`: cuadradito paper con stripe izquierdo `--st-pendiente` (inset shadow 3px)
- `blocked`: cuadradito border dashed `--line`, bg transparent
- Count pill al lado: JetBrains Mono 500 10.5px, bg `--paper-3`, border, padding `1px 6px`, border-radius 999px

**Hint requiere/habilita:**
- Separator vertical 1px
- `requiere` con swatch ámbar 14×3px
- `habilita` con swatch teal 14×3px

**Footer meta (right):**
- "DNI 43581083 · Nac. 08/07/2001" — JetBrains Mono 11px `--ink-3`

---

## Interactions & Behavior

### Hover sobre card
- Resaltado de la card y sus correlativas/dependientes (ver arriba)
- Las líneas SVG cambian opacity y stroke-width
- onMouseLeave: vuelve al estado por defecto

### Filtros
- Click en chip de estado: agrega/quita ese estado del Set activo
- Click en "Todas": limpia el Set
- Las cards que no matchean el filtro reciben `data-faded="1"` (opacity 0.18) — **no se ocultan**, para preservar el layout y las líneas
- El search funciona en conjunto con los filtros (AND)

### Recompute de posiciones para SVG
- En el mount inicial (useLayoutEffect)
- En `ResizeObserver` sobre `malla-inner`
- En `window.resize`
- En `document.fonts.ready.then(...)` — crítico porque sin las fonts cargadas el layout cambia

### Sin interacciones de click
Por ahora las cards no abren ningún detalle/modal. Roadmap: click → drawer lateral con detalle, correlativas listadas, link al sistema académico.

---

## State Management

Estado de la pantalla (en App.jsx):

```
{
  hoveredId: string | null,         // codigo de la materia hovered
  active: Set<StatusKey>,           // estados activos para filtrar
  query: string,                    // texto del search
  positions: Record<codigo, {       // posiciones medidas para SVG
    left, right, top, bottom, midX, midY
  }>
}
```

Estado computado (useMemo):
- `visibleMaterias`: materias con flags derivados `_faded`, `_blocked`, `_blockedBy`
- `stats`: contadores por status + buckets `available`/`blocked` + promedio + horas
- `groups`: agrupado por año + sub-cols por cuatrimestre
- `related`: `{ prereqs: Set, dependents: Set }` para el hover actual

### Source data shape
```ts
{
  student: {
    nombre: string,
    lu: string,
    plan: string,        // ej "ING. EN INFORMÁTICA"
    planCodigo: string,
    documento: string,
    fechaNacimiento: string,
  },
  materias: Array<{
    codigo: string,                 // ej "3.4.075"
    nombre: string,                 // UPPERCASE como viene del sistema
    horas: number,
    situacion: "APROBADO" | "PROMOCIONA" | "EQUIV_INTERNA" | "INSCRIPTO" | "A_FINAL" | "RECURSA" | "PENDIENTE",
    nota?: number,
    año: "PRIMER_AÑO" | "SEGUNDO_AÑO" | "TERCER_AÑO" | "CUARTO_AÑO" | "QUINTO_AÑO" | "OPTATIVAS" | "ANEXO",
    cuatrimestre: 1 | 2,
    correlativas?: string[],        // array de códigos
  }>
}
```

### Datos derivados
- **`bucketOf(m)`:** clasifica una materia en done/active/available/blocked
- **`_blocked`:** boolean, true si situacion=PENDIENTE y alguna correlativa no está aprobada
- **`_blockedBy`:** array de códigos de correlativas faltantes
- **`shortCode(nombre)`:** mnemónico de 2-4 chars (normaliza acentos, ignora stop-words "DE/Y/A/...", convierte Roman I→1, II→2, etc). Ver `app.jsx`.
- **`titleCase(nombre)`:** convierte UPPERCASE a Title Case respetando acentos, números romanos y stop-words.

---

## Design Tokens

### Colores (CSS custom properties)

```css
/* Paper / fondo */
--bg:          #efe6d3;   /* warm cream */
--bg-2:        #e7dcc4;
--paper:       #faf3e2;   /* card bg principal */
--paper-2:     #f6edd7;   /* hover bg */
--paper-3:     #f0e6cc;   /* badges, count pills */

/* Tinta */
--ink:         #2b2418;   /* texto principal */
--ink-2:       #5a4a35;   /* texto secundario */
--ink-3:       #8a7858;   /* metadata */
--ink-4:       #b3a482;   /* muted */

/* Líneas */
--line:        #d9c9a4;
--line-soft:   #e6d8b6;
--line-strong: #c7b485;

/* Acentos */
--accent:      #b8542a;   /* terracotta */
--accent-2:    #9a6a2e;   /* burnt copper */

/* Estados (status colors) */
--st-aprobado:   #5d7c2b;   /* olive */
--st-promociona: #b88420;   /* gold */
--st-equiv:      #8c4a87;   /* plum */
--st-inscripto:  #2a7d77;   /* warm teal */
--st-afinal:     #c2521a;   /* terracotta */
--st-recursa:    #a8324d;   /* wine */
--st-pendiente:  #a39071;   /* tan */
```

### Background del body
```css
body {
  background:
    radial-gradient(1200px 700px at 85% -10%, rgba(184,84,42,0.10), transparent 60%),
    radial-gradient(900px 600px at -10% 110%, rgba(154,106,46,0.08), transparent 60%),
    repeating-linear-gradient(0deg, transparent 0 2px, rgba(80,60,30,0.012) 2px 3px),
    var(--bg);
  background-attachment: fixed;
}
```

### Tipografía

Fuentes (Google Fonts):
- **Fraunces** (serif) — weights 400, 500, 600, 700, 800. Usar para títulos, valores numéricos grandes, nombres de materia. Italic disponible.
- **Manrope** (sans) — weights 400, 500, 600, 700, 800. Usar para UI text, labels, metadata.
- **JetBrains Mono** (mono) — weights 400, 500, 600. Para códigos de materia, counters, horas.

### Spacing scale
- Card padding: `10px 12px 11px`
- Card gap: 10px
- Sub-col gap: 12px
- Y-group gap (interno): 14px
- Section padding horizontal: 32px (en mobile: 18px)

### Border radius
- `--radius`: 12px (cards, tiles, progress card)
- `--radius-sm`: 8px (small badges)
- `10px`: cards de materia
- `999px`: chips, search input, count pills

### Shadows (hard, papel artesanal)
- Card default: `2px 2px 0 --line-soft`
- Card hover: `4px 4px 0 --ink`
- Card prereq: `3px 3px 0 color-mix(--st-afinal 40%, transparent)`
- Card dependent: `3px 3px 0 color-mix(--st-inscripto 40%, transparent)`
- Tile/progress card: `3px 3px 0 --line-soft`
- Brand mark: `2px 2px 0 --ink`

### Breakpoints
- `max-width: 1200px`: stats stack a 1 columna, tiles a 2×2
- `max-width: 720px`: ocultar student info en topbar, reducir padding a 18px

---

## Assets

No assets externos (imágenes, iconos custom). Toda iconografía es SVG inline. Fuentes vía Google Fonts.

Si se migra a un design system con icon library (Lucide, Phosphor, etc), reemplazar los SVGs inline por sus equivalentes manteniendo tamaños:
- Search 14×14px
- Export download arrow 14×14px
- Status icons dentro del circle: 11×11px
- Chevron del year-group: usa el carácter `▾`

---

## Files in this handoff

```
design_handoff_plan_de_estudios/
├── README.md              <- este archivo
├── Plan de Estudios.html  <- entry HTML
├── styles.css             <- todos los estilos
├── app.jsx                <- componente React principal
└── data.js                <- datos de ejemplo (alumno + materias)
```

### `Plan de Estudios.html`
Carga React 18.3.1 + ReactDOM 18.3.1 + Babel Standalone via unpkg con integrity hashes pinneados. Importa Google Fonts (Manrope, Fraunces, JetBrains Mono), `styles.css`, `data.js` (define `window.PLAN_DATA`), y `app.jsx` (transpilado por Babel).

### `app.jsx`
Componentes:
- `App` — root, maneja state y layout
- `MateriaCard` — card individual
- `StatusIcon` — circular badge con glyph según bucket
- `Column` (deprecado, no se usa)
- `SubColumn` — wrapper de un cuatrimestre
- `YearGroup` — wrapper de un año con 2 sub-cols
- `EdgeLayer` — SVG overlay con beziers
- `ProgressRing` — donut con porcentaje
- `StatTile` — card de stats
- `FilterChips` — barra de chips

Helpers:
- `titleCase`, `shortCode`, `bucketOf`, `buildYearGroups`, `computeStats`, `cssVar`

### `data.js`
Define `window.PLAN_DATA = { student, materias }`. En producción, reemplazar por un fetch / SWR / RSC contra el backend.

### `styles.css`
~700 líneas. Todas las CSS custom properties al inicio. Estilos organizados por sección: reset → topbar → stats → toolbar → malla → year-group → sub-col → card → buckets → states → footer → media queries.

---

## Implementation Notes

### Para el desarrollador

1. **Framework target:** si el codebase usa Next.js/React, mover los componentes a `.tsx` con props tipadas. Para Vue/Svelte/otro, mantener la misma estructura conceptual.

2. **Estado:** el state es completamente local al componente raíz, no requiere store global. Si se integra al SaaS, las materias deberían venir de un fetch / RSC / SWR.

3. **CSS:** las CSS custom properties pueden moverse al design system global del codebase. Considerar migrar a Tailwind tokens o a un theme provider si el codebase lo usa. **No usar Tailwind como reemplazo directo** — los tokens (especialmente `color-mix`) requieren CSS nativo.

4. **`color-mix(in oklab, …)`:** requiere navegadores modernos (Chrome 111+, Safari 16.4+, Firefox 113+). Si hay que soportar más viejos, precalcular los mixes.

5. **SVG edge layer:** el cálculo de posiciones depende de `getBoundingClientRect()` post-layout. Asegurar que se re-calcule en:
   - Mount
   - ResizeObserver sobre el contenedor
   - `document.fonts.ready` (Fraunces cambia métricas al cargar)
   - Cambios de filtros que alteren heights de cards
   - Scroll (no necesario si SVG es child del scroll container, que es el caso)

6. **Performance:** con ~54 materias y ~30 edges, render es trivial. Si se escala a planes con cientos de materias, considerar virtualizar o renderizar solo edges visibles en viewport.

7. **A11y:**
   - Las cards no son focusables actualmente — agregar `tabIndex={0}` y focus styles
   - Status icons tienen `aria-hidden="true"` — bien
   - `title` attr en cards muestra "código — estado"
   - Faltan ARIA labels en filter chips (`aria-pressed`)
   - Reducir movimiento si `prefers-reduced-motion`

8. **i18n:** todo el texto está en español hardcodeado. Mover a un i18n provider (next-intl, react-i18next) si el SaaS lo requiere.

9. **Roadmap (no implementado):**
   - Click en card → drawer/modal con detalle (correlativas listadas, profesores, comisiones, link al sistema académico)
   - Click en materia bloqueada → highlight + scroll a las correlativas faltantes
   - Toggle "ver solo aprobables" (filtro virtual: bucket=available)
   - Drag & drop para planificar cuatrimestre tentativo
   - Export PDF / imagen del roadmap
   - Vista lista alternativa (vs malla)

### Anti-patrones a evitar

- **No** convertir las cards a links si no llevan a ninguna parte (en el HTML están como `<div>`, que está bien).
- **No** ocultar cards con `display: none` al filtrar — rompería las líneas SVG. Usar opacity.
- **No** poner los SVG edges en un layer fuera del scroll container — tienen que scrollear junto a las cards.
- **No** usar Inter como fallback de Fraunces — métricas muy distintas, el layout se rompe. Fraunces tiene un fallback adecuado en Manrope.

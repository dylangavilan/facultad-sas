/* global React, ReactDOM */
const { useState, useMemo, useRef, useEffect, useLayoutEffect } = React;

// ── status meta ────────────────────────────────────────────────────────────
const STATUS = {
  PROMOCIONA:    { label: "Promocionada", varName: "--st-promociona", order: 0 },
  APROBADO:      { label: "Aprobada",     varName: "--st-aprobado",   order: 1 },
  EQUIV_INTERNA: { label: "Equivalencia", varName: "--st-equiv",      order: 2 },
  INSCRIPTO:     { label: "Cursando",     varName: "--st-inscripto",  order: 3 },
  A_FINAL:       { label: "A final",      varName: "--st-afinal",     order: 4 },
  RECURSA:       { label: "Recursa",      varName: "--st-recursa",    order: 5 },
  PENDIENTE:     { label: "Pendiente",    varName: "--st-pendiente",  order: 6 },
};
const APPROVED_STATUSES = new Set(["APROBADO", "PROMOCIONA", "EQUIV_INTERNA"]);

const YEAR_LABELS = {
  PRIMER_AÑO:  "Primer año",
  SEGUNDO_AÑO: "Segundo año",
  TERCER_AÑO:  "Tercer año",
  CUARTO_AÑO:  "Cuarto año",
  QUINTO_AÑO:  "Quinto año",
  OPTATIVAS:   "Optativas",
  ANEXO:       "Anexo",
};
const YEAR_ORDER = ["PRIMER_AÑO","SEGUNDO_AÑO","TERCER_AÑO","CUARTO_AÑO","QUINTO_AÑO","OPTATIVAS","ANEXO"];

const LOWER_WORDS = new Set(["de", "del", "y", "a", "e", "en", "la", "el", "las", "los"]);
const ROMAN_RE = /^(i{1,3}|iv|vi{0,3}|ix|x)\.?$/i;
const titleCase = (s) => {
  const lower = s.toLowerCase();
  return lower.split(/(\s+)/).map((word, i) => {
    if (!word || /^\s+$/.test(word)) return word;
    if (ROMAN_RE.test(word.replace(/\.$/, ""))) return word.toUpperCase();
    if (i > 0 && LOWER_WORDS.has(word)) return word;
    return word.charAt(0).toUpperCase() + word.slice(1);
  }).join("");
};

// resolve a CSS var to a hex (for SVG strokes — they can't use var() in attributes reliably across browsers, but they do in modern browsers; we'll inline)
function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

// ── short code (TS, SI2, ID1) ──────────────────────────────────────────────
const STOP_CODE = new Set(["DE","DEL","Y","A","E","EN","LA","EL","LAS","LOS","DEL"]);
const ROMAN_MAP = { I:"1", II:"2", III:"3", IV:"4", V:"5", VI:"6" };
function shortCode(nombre) {
  // strip accents so "ÁLGEBRA" -> "ALGEBRA" -> A, not Á
  const ascii = nombre.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const cleaned = ascii.toUpperCase().replace(/[.,]/g, "");
  const words = cleaned.split(/\s+/).filter((w) => w && !STOP_CODE.has(w));
  const parts = [];
  for (const w of words) {
    if (ROMAN_MAP[w]) parts.push(ROMAN_MAP[w]);
    else parts.push(w[0]);
  }
  let code = parts.join("");
  if (code.length < 2 || code.length > 4) {
    code = (words[0] || ascii).slice(0, 3);
  }
  return code.slice(0, 4);
}

// ── year groups ────────────────────────────────────────────────────────────
function buildYearGroups(materias) {
  const groups = [];
  for (const y of YEAR_ORDER) {
    if (y === "OPTATIVAS" || y === "ANEXO") continue;
    const items = materias.filter((m) => m.año === y);
    if (!items.length) continue;
    groups.push({
      id: y, label: YEAR_LABELS[y], kind: "regular", items,
      cols: [
        { id: `${y}-1`, label: "1° Cuatrimestre", items: items.filter((m) => m.cuatrimestre === 1) },
        { id: `${y}-2`, label: "2° Cuatrimestre", items: items.filter((m) => m.cuatrimestre === 2) },
      ],
    });
  }
  // extras combined (Optativas + Anexo)
  const opt = materias.filter((m) => m.año === "OPTATIVAS");
  const anx = materias.filter((m) => m.año === "ANEXO");
  if (opt.length || anx.length) {
    const cols = [];
    if (opt.length) cols.push({ id: "OPT", label: "Optativas", items: opt });
    if (anx.length) cols.push({ id: "ANX", label: "Anexo", items: anx });
    groups.push({ id: "EXTRAS", label: "Extras", kind: "extra", items: [...opt, ...anx], cols });
  }
  return groups;
}

// ── card ───────────────────────────────────────────────────────────────────
const BUCKETS = {
  done:      { label: "Hechas",      desc: "Aprobada, promocionada o equivalencia" },
  active:    { label: "En curso",    desc: "Cursando, a final o recursando" },
  available: { label: "Disponibles", desc: "Correlativas listas" },
  blocked:   { label: "Bloqueadas",  desc: "Faltan correlativas" },
};
function bucketOf(m) {
  if (["APROBADO", "PROMOCIONA", "EQUIV_INTERNA"].includes(m.situacion)) return "done";
  if (["INSCRIPTO", "A_FINAL", "RECURSA"].includes(m.situacion)) return "active";
  return m._blocked ? "blocked" : "available";
}

// ── status icons (small circular badge inside card) ───────────────────────
function StatusIcon({ bucket, situacion }) {
  // SVG glyph per bucket
  const glyph = {
    done: (
      <svg viewBox="0 0 16 16" width="11" height="11"><path d="M3.5 8.5 L7 12 L13 4.5" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
    ),
    active: situacion === "A_FINAL" ? (
      <svg viewBox="0 0 16 16" width="11" height="11"><path d="M8 3 V9 M8 12 V12.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"/></svg>
    ) : situacion === "RECURSA" ? (
      <svg viewBox="0 0 16 16" width="11" height="11"><path d="M12 5 A4 4 0 1 0 13 9" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><path d="M10 3 L13 5 L11 8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
    ) : (
      <svg viewBox="0 0 16 16" width="11" height="11"><circle cx="8" cy="8" r="2.5" fill="currentColor"/></svg>
    ),
    available: (
      <svg viewBox="0 0 16 16" width="11" height="11"><path d="M3 4 H7 a2 2 0 0 1 2 2 V13 a2 2 0 0 0 -2 -2 H3 Z M13 4 H9 a2 2 0 0 0 -2 2 V13 a2 2 0 0 1 2 -2 H13 Z" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"/></svg>
    ),
    blocked: (
      <svg viewBox="0 0 16 16" width="11" height="11"><rect x="3.5" y="7.5" width="9" height="6" rx="1.2" fill="currentColor"/><path d="M5.5 7.5 V5.2 a2.5 2.5 0 0 1 5 0 V7.5" fill="none" stroke="currentColor" strokeWidth="1.6"/></svg>
    ),
  };
  return (
    <span className="status-icon" data-bucket={bucket}>
      {glyph[bucket]}
    </span>
  );
}

function MateriaCard({ m, related, hoveredId, registerRef, onHover, onLeave }) {
  const st = STATUS[m.situacion];
  const isHovered = hoveredId === m.codigo;
  const isPrereq = related.prereqs.has(m.codigo);
  const isDependent = related.dependents.has(m.codigo);
  const isDim = hoveredId && !isHovered && !isPrereq && !isDependent;
  const bucket = bucketOf(m);
  const relAttr = isHovered ? "hovered" : isPrereq ? "prereq" : isDependent ? "dependent" : "none";

  const yearLabel = ({
    PRIMER_AÑO: "Año 1",
    SEGUNDO_AÑO: "Año 2",
    TERCER_AÑO: "Año 3",
    CUARTO_AÑO: "Año 4",
    QUINTO_AÑO: "Año 5",
    OPTATIVAS: "Optativa",
    ANEXO: "Anexo",
  })[m.año] || "";
  const cuatriLabel = m.cuatrimestre ? `· C${m.cuatrimestre}` : "";

  return (
    <div
      ref={(el) => registerRef(m.codigo, el)}
      className="card"
      data-status={m.situacion}
      data-bucket={bucket}
      data-hovered={isHovered ? "1" : "0"}
      data-related={relAttr}
      data-faded={m._faded ? "1" : "0"}
      data-dim={isDim ? "1" : "0"}
      style={{ ["--accent"]: `var(${st.varName})` }}
      onMouseEnter={() => onHover(m.codigo)}
      onMouseLeave={onLeave}
      title={`${m.codigo} — ${st.label}`}
    >
      <div className="card-row">
        <StatusIcon bucket={bucket} situacion={m.situacion} />
        <div className="card-short" title={m.codigo}>{shortCode(m.nombre)}</div>
      </div>
      <div className="nombre">{titleCase(m.nombre)}</div>
      <div className="card-foot">
        <span className="card-meta">
          {yearLabel} {cuatriLabel}
          {m.horas > 0 && <span className="card-meta-h"> · {m.horas}h</span>}
        </span>
        {typeof m.nota === "number" && (
          <span className="nota" title="Nota">{m.nota}</span>
        )}
      </div>
      {bucket === "blocked" && m._blockedBy?.length > 0 && (
        <div className="blocked-meta">
          <span>Falta</span> <strong>{m._blockedBy.length}</strong> {m._blockedBy.length === 1 ? "correlativa" : "correlativas"}
        </div>
      )}
    </div>
  );
}

// ── year group (header + 2 cuatri sub-columns) ────────────────────────────
function SubColumn({ col, ...rest }) {
  return (
    <div className="subcol">
      <div className="subcol-head">{col.label}</div>
      <div className="subcol-cards">
        {col.items.map((m) => (
          <MateriaCard key={m.codigo} m={m} {...rest} />
        ))}
      </div>
    </div>
  );
}

function YearGroup({ group, ...rest }) {
  const approved = group.items.filter((m) => APPROVED_STATUSES.has(m.situacion)).length;
  const total = group.items.length;
  const pct = total ? (approved / total) * 100 : 0;
  return (
    <div className="ygroup" data-kind={group.kind}>
      <div className="ygroup-head">
        <div className="ygroup-title">
          <span className="ygroup-chev" aria-hidden="true">▾</span>
          <span className="ygroup-label">{group.label}</span>
        </div>
        <div className="ygroup-progress">
          <div className="ygroup-bar"><div className="ygroup-fill" style={{ width: `${pct}%` }} /></div>
          <span className="ygroup-count">{approved}/{total}</span>
        </div>
      </div>
      <div className="ygroup-cols" data-cols={group.cols.length}>
        {group.cols.map((c) => (
          <SubColumn key={c.id} col={c} {...rest} />
        ))}
      </div>
    </div>
  );
}

// ── edge layer ─────────────────────────────────────────────────────────────
function EdgeLayer({ materias, positions, hoveredId, related, statusColors }) {
  // build edges: from correlativa -> dependent materia
  const edges = useMemo(() => {
    const out = [];
    for (const m of materias) {
      if (!m.correlativas) continue;
      const dst = positions[m.codigo];
      if (!dst) continue;
      for (const srcCode of m.correlativas) {
        const src = positions[srcCode];
        if (!src) continue;
        out.push({ from: srcCode, to: m.codigo, src, dst, dstStatus: m.situacion });
      }
    }
    return out;
  }, [materias, positions]);

  if (!edges.length) return null;

  const width  = Math.max(...Object.values(positions).map(p => p.right), 0) + 4;
  const height = Math.max(...Object.values(positions).map(p => p.bottom), 0) + 4;

  return (
    <svg className="edges" width={width} height={height} viewBox={`0 0 ${width} ${height}`}>
      <defs>
        {Object.entries(STATUS).map(([k, s]) => (
          <marker
            key={k}
            id={`arr-${k}`}
            viewBox="0 0 10 10"
            refX="9" refY="5"
            markerWidth="5" markerHeight="5"
            orient="auto-start-reverse"
          >
            <path d="M0,0 L10,5 L0,10 Z" fill={statusColors[k] || "#888"} />
          </marker>
        ))}
      </defs>
      {edges.map((e, i) => {
        const isActive = hoveredId && (e.from === hoveredId || e.to === hoveredId);
        const isDim = hoveredId && !isActive;
        const color = statusColors[e.dstStatus] || "#888";
        const x1 = e.src.right;
        const y1 = e.src.midY;
        const x2 = e.dst.left;
        const y2 = e.dst.midY;
        const dx = Math.max(Math.abs(x2 - x1) * 0.45, 60);
        const d = `M ${x1},${y1} C ${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}`;
        return (
          <g style={{ opacity: isDim ? 0.06 : isActive ? 1 : 0.55 }} key={i}>
            <path
              d={d}
              fill="none"
              stroke={color}
              strokeWidth={isActive ? 2.4 : 1.6}
              strokeLinecap="round"
              markerEnd={`url(#arr-${e.dstStatus})`}
            />
            {isActive && (
              <circle cx={x1} cy={y1} r="3.5" fill={color} />
            )}
          </g>
        );
      })}
    </svg>
  );
}

// ── stats / header bits ────────────────────────────────────────────────────
function computeStats(materias) {
  const total = materias.length;
  const approved = materias.filter((m) => APPROVED_STATUSES.has(m.situacion));
  const withGrade = approved.filter((m) => typeof m.nota === "number");
  const avg = withGrade.length
    ? withGrade.reduce((a, m) => a + m.nota, 0) / withGrade.length
    : 0;
  const horasTotal = materias.reduce((a, m) => a + m.horas, 0);
  const horasAprob = approved.reduce((a, m) => a + m.horas, 0);
  const byStatus = {};
  for (const k of Object.keys(STATUS)) byStatus[k] = 0;
  for (const m of materias) byStatus[m.situacion] = (byStatus[m.situacion] || 0) + 1;

  // bucket counts
  const byCode = Object.fromEntries(materias.map((m) => [m.codigo, m]));
  let available = 0, blocked = 0;
  for (const m of materias) {
    if (m.situacion !== "PENDIENTE") continue;
    const correl = m.correlativas || [];
    const allOk = correl.every((c) => {
      const s = byCode[c];
      return s && APPROVED_STATUSES.has(s.situacion);
    });
    if (allOk) available++; else blocked++;
  }
  return { total, approvedCount: approved.length, avg, horasTotal, horasAprob, byStatus, available, blocked };
}

function StatTile({ label, value, sub, accent }) {
  return (
    <div className="stat-tile" style={{ ["--acc"]: accent || "var(--ink)" }}>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {sub && <div className="stat-sub">{sub}</div>}
    </div>
  );
}

function ProgressRing({ pct, size = 92, stroke = 8 }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - pct / 100);
  return (
    <svg width={size} height={size} className="ring">
      <circle cx={size / 2} cy={size / 2} r={r} stroke="var(--bg-2)" strokeWidth={stroke} fill="none" />
      <circle
        cx={size / 2} cy={size / 2} r={r}
        stroke="url(#ringGrad)" strokeWidth={stroke} fill="none"
        strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      <defs>
        <linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--st-promociona)" />
          <stop offset="100%" stopColor="var(--st-aprobado)" />
        </linearGradient>
      </defs>
      <text x="50%" y="50%" textAnchor="middle" dy="0.35em" className="ring-text">
        {Math.round(pct)}%
      </text>
    </svg>
  );
}

function FilterChips({ stats, active, onToggle, onClear, statusColors }) {
  return (
    <div className="chips">
      <button className={`chip ${active.size === 0 ? "on" : ""}`} onClick={onClear}>
        <span className="chip-dot" style={{ background: "linear-gradient(135deg, var(--st-promociona), var(--st-aprobado))" }} />
        Todas
        <span className="chip-count">{stats.total}</span>
      </button>
      {Object.entries(STATUS)
        .sort((a, b) => a[1].order - b[1].order)
        .map(([key, s]) => (
          <button
            key={key}
            className={`chip ${active.has(key) ? "on" : ""}`}
            onClick={() => onToggle(key)}
            style={{ ["--c"]: statusColors[key] || "var(--ink-3)" }}
          >
            <span className="chip-dot" style={{ background: statusColors[key] || "var(--ink-3)" }} />
            {s.label}
            <span className="chip-count">{stats.byStatus[key] || 0}</span>
          </button>
        ))}
    </div>
  );
}

// ── app ────────────────────────────────────────────────────────────────────
function App() {
  const { student, materias } = window.PLAN_DATA;
  const [hoveredId, setHoveredId] = useState(null);
  const [active, setActive] = useState(new Set());
  const [query, setQuery] = useState("");
  const [positions, setPositions] = useState({});

  const innerRef = useRef(null);
  const cardRefs = useRef({});

  const statusColors = useMemo(() => {
    const out = {};
    for (const [k, s] of Object.entries(STATUS)) out[k] = cssVar(s.varName) || "#888";
    return out;
  }, []);

  const matchesFilter = (m) => {
    const statusOk = active.size === 0 || active.has(m.situacion);
    const q = query.trim().toLowerCase();
    const queryOk = !q || m.nombre.toLowerCase().includes(q) || m.codigo.toLowerCase().includes(q);
    return statusOk && queryOk;
  };

  const visibleMaterias = useMemo(() => {
    // compute blocked flag for each PENDIENTE materia: blocked if any correlativa is NOT in APPROVED set
    const byCode = Object.fromEntries(materias.map((m) => [m.codigo, m]));
    return materias.map((m) => {
      const blockedBy = (m.correlativas || []).filter((c) => {
        const src = byCode[c];
        return !src || !APPROVED_STATUSES.has(src.situacion);
      });
      const isBlocked = m.situacion === "PENDIENTE" && blockedBy.length > 0;
      return { ...m, _faded: !matchesFilter(m), _blocked: isBlocked, _blockedBy: blockedBy };
    });
  }, [materias, active, query]);

  const stats = useMemo(() => computeStats(materias), [materias]);
  const pct = (stats.approvedCount / stats.total) * 100;
  const groups = useMemo(() => buildYearGroups(visibleMaterias), [visibleMaterias]);

  const related = useMemo(() => {
    const prereqs = new Set();
    const dependents = new Set();
    if (!hoveredId) return { prereqs, dependents };
    const byCode = Object.fromEntries(materias.map((m) => [m.codigo, m]));
    const target = byCode[hoveredId];
    if (target?.correlativas) target.correlativas.forEach((c) => prereqs.add(c));
    for (const m of materias) {
      if (m.correlativas?.includes(hoveredId)) dependents.add(m.codigo);
    }
    return { prereqs, dependents };
  }, [hoveredId, materias]);

  const registerRef = (code, el) => {
    if (el) cardRefs.current[code] = el;
    else delete cardRefs.current[code];
  };

  // measure positions of every card relative to the inner container
  const measure = () => {
    const inner = innerRef.current;
    if (!inner) return;
    const innerRect = inner.getBoundingClientRect();
    const out = {};
    for (const [code, el] of Object.entries(cardRefs.current)) {
      if (!el || !el.isConnected) continue;
      const r = el.getBoundingClientRect();
      out[code] = {
        left:   r.left   - innerRect.left,
        right:  r.right  - innerRect.left,
        top:    r.top    - innerRect.top,
        bottom: r.bottom - innerRect.top,
        midY:   r.top    - innerRect.top + r.height / 2,
        midX:   r.left   - innerRect.left + r.width / 2,
      };
    }
    setPositions(out);
  };

  useLayoutEffect(() => {
    measure();
    const ro = new ResizeObserver(() => measure());
    if (innerRef.current) ro.observe(innerRef.current);
    window.addEventListener("resize", measure);
    if (document.fonts?.ready) document.fonts.ready.then(measure);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, [groups]);

  const toggle = (key) => {
    const next = new Set(active);
    next.has(key) ? next.delete(key) : next.add(key);
    setActive(next);
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">
            <svg viewBox="0 0 32 32" width="20" height="20">
              <path d="M6 22 L16 8 L26 22" fill="none" stroke="var(--ink)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <circle cx="16" cy="8" r="2" fill="var(--accent)" />
              <circle cx="6" cy="22" r="2" fill="var(--ink)" />
              <circle cx="26" cy="22" r="2" fill="var(--ink)" />
            </svg>
          </div>
          <div className="brand-meta">
            <div className="brand-name">facultad·sas</div>
            <div className="brand-sub">Plan de estudios</div>
          </div>
        </div>

        <div className="student">
          <div className="student-name">{titleCase(student.nombre)}</div>
          <div className="student-meta">
            <span>LU {student.lu}</span>
            <span className="dotsep" />
            <span>{student.plan}</span>
            <span className="dotsep" />
            <span>Plan {student.planCodigo}</span>
          </div>
        </div>

        <div className="topbar-actions">
          <button className="icon-btn" title="Exportar">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 3v12m0 0l4-4m-4 4l-4-4M5 21h14"/></svg>
            Exportar
          </button>
          <button className="icon-btn primary" title="Vista">Malla</button>
        </div>
      </header>

      <section className="stats-row">
        <div className="stats-progress">
          <ProgressRing pct={pct} />
          <div className="stats-progress-meta">
            <div className="stats-progress-label">Progreso del plan</div>
            <div className="stats-progress-value">
              <strong>{stats.approvedCount}</strong>
              <span>de {stats.total} materias</span>
            </div>
            <div className="stats-progress-bar">
              <div className="bar-fill" style={{ width: `${pct}%` }} />
            </div>
            <div className="stats-progress-avg">
              <span className="avg-label">Promedio</span>
              <span className="avg-value">{stats.avg.toFixed(2)}</span>
              <span className="avg-sub">sobre {materias.filter(m => typeof m.nota === "number").length} con nota</span>
            </div>
          </div>
        </div>
        <div className="stats-tiles">
          <StatTile label="Hechas" value={stats.approvedCount} sub={`${stats.horasAprob} h cursadas`} accent="var(--st-aprobado)" />
          <StatTile label="En curso" value={stats.byStatus.INSCRIPTO + stats.byStatus.A_FINAL + stats.byStatus.RECURSA} sub={`${stats.byStatus.INSCRIPTO} cursando · ${stats.byStatus.A_FINAL} a final`} accent="var(--st-inscripto)" />
          <StatTile label="Disponibles" value={stats.available} sub="con correlativas listas" accent="var(--st-promociona)" />
          <StatTile label="Bloqueadas" value={stats.blocked} sub="falta cursar correlativas" accent="var(--st-pendiente)" />
        </div>
      </section>

      <section className="toolbar">
        <FilterChips
          stats={stats}
          active={active}
          onToggle={toggle}
          onClear={() => setActive(new Set())}
          statusColors={statusColors}
        />
        <div className="search">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
          <input
            placeholder="Buscar materia o código…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </section>

      <div className="malla-wrap">
        <div className="malla">
          <div className="malla-inner" ref={innerRef}>
            <EdgeLayer
              materias={materias}
              positions={positions}
              hoveredId={hoveredId}
              related={related}
              statusColors={statusColors}
            />
            {groups.map((group) => (
              <YearGroup
                key={group.id}
                group={group}
                related={related}
                hoveredId={hoveredId}
                registerRef={registerRef}
                onHover={(id) => setHoveredId(id)}
                onLeave={() => setHoveredId(null)}
              />
            ))}
          </div>
        </div>
      </div>

      <footer className="footer">
        <div className="legend-buckets">
          <span className="bk-chip" data-bucket="done">
            <span className="bk-swatch" />
            Hechas <span className="bk-count">{stats.approvedCount}</span>
          </span>
          <span className="bk-chip" data-bucket="active">
            <span className="bk-swatch" />
            En curso <span className="bk-count">{stats.byStatus.INSCRIPTO + stats.byStatus.A_FINAL + stats.byStatus.RECURSA}</span>
          </span>
          <span className="bk-chip" data-bucket="available">
            <span className="bk-swatch" />
            Disponibles <span className="bk-count">{stats.available}</span>
          </span>
          <span className="bk-chip" data-bucket="blocked">
            <span className="bk-swatch" />
            Bloqueadas <span className="bk-count">{stats.blocked}</span>
          </span>
          <span className="legend-sep" />
          <span className="legend-hint">
            <span className="hint-swatch" style={{ background: "var(--st-afinal)" }} />
            <span>requiere</span>
            <span className="hint-swatch" style={{ background: "var(--st-inscripto)", marginLeft: 6 }} />
            <span>habilita</span>
          </span>
        </div>
        <div className="footer-meta">
          DNI {student.documento} · Nac. {student.fechaNacimiento}
        </div>
      </footer>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);

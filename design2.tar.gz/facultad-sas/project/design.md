# facultad·sas — Design System

Guía para crear pantallas nuevas dentro del producto. La pantalla de referencia es **Plan de Estudios.html** — todo lo que está acá ya está aplicado ahí, en `styles.css`.

> **Regla de oro:** todo viene de tokens. No inventes colores, tamaños, sombras ni radios por fuera de los definidos abajo. Si necesitás algo que no existe, agregalo como token primero.

---

## 1. Vibe / dirección visual

**Papel cálido + tinta + sello a mano.** No es "material design", no es "glass", no es flat moderno. Es una grilla académica impresa en un cuaderno marrón claro:

- Fondos beige/crema (no blanco, nunca `#fff`).
- Tinta marrón oscura (no negro puro).
- Sombras **duras** (`Npx Npx 0 color` — sin blur), como un sello desplazado.
- Acentos terracota / oliva / oro / vino — colores tierra, no neón.
- Tipografía: serif elegante (Fraunces) para títulos y números; sans humanista (Manrope) para UI; mono (JetBrains Mono) para códigos y conteos.
- Texturas sutiles en el `body` (grano de papel + radial gradients tenues).

**Antipatrones a evitar:**
- ❌ Blanco puro, gris frío (`#fff`, `#000`, `#888`).
- ❌ Sombras blur grandes (`0 10px 40px rgba(0,0,0,0.1)`).
- ❌ Gradientes saturados de marca SaaS (violeta → rosa, etc).
- ❌ Iconos rellenos genéricos. Preferir SVG inline simples, line-style.
- ❌ Emojis.
- ❌ Border-radius enorme (>16px) en cards. Estamos en territorio papel, no app móvil.

---

## 2. Tokens (CSS custom properties)

Todos definidos en `:root` en `styles.css`. Usalos siempre vía `var(--…)`.

### 2.1 Color

```css
/* Fondo / papel */
--bg          #efe6d3   /* fondo de página */
--bg-2        #e7dcc4   /* fondo más oscuro / tracks */
--paper       #faf3e2   /* fondo de cards / tiles */
--paper-2     #f6edd7   /* hover de cards */
--paper-3     #f0e6cc   /* badges, count pills, code chips */

/* Tinta */
--ink         #2b2418   /* texto principal, botones primary */
--ink-2       #5a4a35   /* texto secundario */
--ink-3       #8a7858   /* metadata, labels uppercase */
--ink-4       #b3a482   /* muted, placeholders */

/* Líneas */
--line        #d9c9a4   /* borde default de cards */
--line-soft   #e6d8b6   /* divisores, sombras suaves */
--line-strong #c7b485   /* hover de bordes, scrollbar thumb */

/* Acentos */
--accent      #b8542a   /* terracotta — principal */
--accent-2    #9a6a2e   /* burnt copper — secundario */

/* Estados (status colors) */
--st-aprobado    #5d7c2b  /* olive — éxito */
--st-promociona  #b88420  /* gold — éxito alto */
--st-equiv       #8c4a87  /* plum — info */
--st-inscripto   #2a7d77  /* teal — en proceso */
--st-afinal      #c2521a  /* terracotta — alerta */
--st-recursa     #a8324d  /* wine — error */
--st-pendiente   #a39071  /* tan — neutro/wait */
```

**Cómo usarlos semánticamente en otras pantallas:**
- Éxito / completado → `--st-aprobado` (o `--st-promociona` si querés celebrar).
- En curso / activo → `--st-inscripto`.
- Atención / warning → `--st-afinal`.
- Error / destructivo → `--st-recursa`.
- Pendiente / vacío → `--st-pendiente` o `--ink-4`.
- Info neutra → `--st-equiv`.
- CTA / link principal → `--accent`.

**Mezclas:** preferir `color-mix(in oklab, var(--accent) 16%, var(--paper))` antes que un nuevo hex. Soporta Chrome 111+ / Safari 16.4+ / Firefox 113+.

### 2.2 Tipografía

Tres familias, cargadas desde Google Fonts en el `<head>`:

```html
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,wght@0,400..700;1,400..600&family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
```

| Familia | Uso | Pesos |
|---|---|---|
| **Fraunces** (serif) | Títulos, números grandes, nombres "humanos" (materias, alumnos, secciones). Italic 600 18px para el brand. | 400 / 500 / 600 / 700 / 800 |
| **Manrope** (sans) | UI: botones, chips, labels, texto secundario, inputs. **Default del `<body>`.** | 400 / 500 / 600 / 700 / 800 |
| **JetBrains Mono** | Códigos (LU, materia), conteos, horas, fechas técnicas. | 400 / 500 / 600 |

**Escala (no usar otros tamaños sin razón fuerte):**

| Token implícito | Tamaño | Familia / peso | Uso |
|---|---|---|---|
| `display` | 32–34px | Fraunces 600 | Valor grande en tile / hero number |
| `h1` | 30px | Fraunces 600 | Stat principal (ej "16 de 54") |
| `h2` | 22px | Fraunces 600 | Subvalor (ej promedio 7.46) |
| `h3` | 18px | Fraunces 600 | Header de sección / brand name |
| `body` | 14px | Manrope 500 / Fraunces 500 | Texto principal, nombres de cards |
| `meta` | 12–13px | Manrope 500 | Metadata, valor de progreso |
| `label` | 10.5px | Manrope 700 uppercase letter-spacing 0.16em | Etiqueta de sección, "PROGRESO DEL PLAN" |
| `caption` | 10–11.5px | Manrope 500 / Mono | Footer meta, sub-textos |

**Reglas:**
- `text-wrap: balance` en títulos serif.
- `letter-spacing: -0.01em` a `-0.02em` en serif grande.
- `letter-spacing: 0.16em` en labels uppercase.
- Nombres en MAYÚSCULA del sistema legacy → pasar por `titleCase()` (ver `app.jsx`) antes de mostrar.

### 2.3 Spacing

No hay tokens dedicados — usamos pixels directos con consistencia:

| Contexto | Valor |
|---|---|
| Padding horizontal de sección | **32px** (desktop), 18px (mobile <720px) |
| Padding vertical de sección | 14–22px |
| Gap entre cards | 10px |
| Gap entre sub-columnas | 12px |
| Gap entre grupos / secciones | 14–22px |
| Padding interior de card | `10px 12px 11px` |
| Padding interior de tile | `16px 18px` |
| Padding interior de tarjeta grande | `18px 22px` |
| Altura de chips / pills / inputs | **34px** |

### 2.4 Border-radius

| Token | Valor | Uso |
|---|---|---|
| `--radius` | **12px** | Cards grandes, tiles, progress card |
| `--radius-sm` | **8px** | Badges chicos, notas |
| (inline) | **10px** | Cards de materia (chico, justo entre 8 y 12) |
| (inline) | **6px** | Code chips (mono) |
| (inline) | **999px** | Pills: chips, search, botones, count badges |

> No uses radius >12px en cards. Rompe el lenguaje "papel".

### 2.5 Sombras (hard / sello)

**Siempre `Npx Npx 0 color` — offset, sin blur.** Como tinta corrida.

| Caso | Sombra |
|---|---|
| Card default | `2px 2px 0 var(--line-soft)` |
| Tile / progress card | `3px 3px 0 var(--line-soft)` |
| Brand mark | `2px 2px 0 var(--ink)` |
| Botón primary | `2px 2px 0 rgba(43,36,24,0.18)` |
| Card hover | `4px 4px 0 var(--ink)` |
| Card "relacionada" (prereq) | `3px 3px 0 color-mix(in oklab, var(--st-afinal) 40%, transparent)` |
| Card "relacionada" (dependiente) | `3px 3px 0 color-mix(in oklab, var(--st-inscripto) 40%, transparent)` |

**Nunca uses `box-shadow: 0 Npx Npx rgba(...)` con blur.** Mata el lenguaje.

### 2.6 Bordes

- Default: `1px solid var(--line)`.
- Activo / destacado: `1.5px solid var(--accent)` (o el color del estado).
- Vacío / placeholder / bloqueado: `1px dashed var(--line)`.
- Divisor interno: `1px dashed var(--line)` (con `border-top` o `border-bottom`).

### 2.7 Fondo del `body`

Ya está en `styles.css`. Si creás un HTML nuevo, copialo:

```css
body {
  background:
    radial-gradient(1200px 700px at 85% -10%, rgba(184,84,42,0.10), transparent 60%),
    radial-gradient(900px 600px at -10% 110%, rgba(154,106,46,0.08), transparent 60%),
    repeating-linear-gradient(0deg, transparent 0 2px, rgba(80,60,30,0.012) 2px 3px),
    var(--bg);
  background-attachment: fixed;
}
```

---

## 3. Componentes base (recipes)

### 3.1 Topbar (sticky)

```
[brand 40px circle] facultad·sas    [contexto/usuario]    [acciones secundarias] [primary]
                    PLAN DE ESTUDIOS
```

- Grid `minmax(220px, 280px) 1fr auto`, gap 32px, padding `18px 32px`.
- Background: `rgba(239, 230, 211, 0.78)` + `backdrop-filter: blur(8px)`.
- `position: sticky; top: 0; z-index: 10`.
- Border-bottom `1px solid var(--line-soft)`.
- **Brand mark**: círculo 40×40, `--paper`, border `1.5px var(--ink)`, hard shadow `2px 2px 0 var(--ink)`, contiene SVG simple (triangulito con dot ámbar).
- **Brand name**: Fraunces italic 600 18px. Sub: Manrope 700 10.5px uppercase letter-spacing 0.16em.

### 3.2 Botones

Pill 34px de alto, padding `0 14px`, font Manrope 600 12.5px, border-radius 999px.

```css
/* Secondary (default) */
background: var(--paper);
border: 1px solid var(--line);
color: var(--ink-2);

/* Hover */
background: var(--paper-2);
border-color: var(--line-strong);
color: var(--ink);

/* Primary */
background: var(--ink);
color: var(--paper);
border: 1px solid var(--ink);
box-shadow: 2px 2px 0 rgba(43,36,24,0.18);

/* Primary hover */
background: #1c1812;

/* Destructive (raro — usar con cuidado) */
background: var(--paper);
color: var(--st-recursa);
border: 1px solid color-mix(in oklab, var(--st-recursa) 40%, var(--line));
```

### 3.3 Chips (filtros, tags)

Mismo lenguaje que botón secondary pero más compacto:
- Padding `6px 13px 6px 11px`, font Manrope 600 12.5px.
- Borde `1px var(--line)`, radio 999px.
- Si tiene **dot**: 8×8 circle, `box-shadow: 0 0 0 2px var(--paper)`, border `1px rgba(43,36,24,0.2)`.
- Si tiene **count**: JetBrains Mono 11px 500 a la derecha, color `--ink-3`.
- Estado `.on`: bg `var(--ink)`, color `var(--paper)`, border `var(--ink)`.

### 3.4 Input / search

Mismo pill 34px, padding `0 14px`, gap 8px con icon SVG 14×14 stroke `currentColor` color `--ink-3`. Input transparente, font Manrope 500 13px. Placeholder `--ink-4`.

### 3.5 Cards

**Lo importante:** una card es papel con borde y sombra dura. Las variantes se hacen con `data-bucket`.

```css
.card {
  background: var(--paper);
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 10px 12px 11px;
  box-shadow: 2px 2px 0 var(--line-soft);
  display: flex;
  flex-direction: column;
  gap: 6px;
}
```

**4 buckets visuales** (replicables a cualquier dominio):

| Bucket | Caso | Visual |
|---|---|---|
| `done` | Cosa completada / éxito | Bg gradiente tintado (`color-mix(--accent 18%, --paper)` → `9%`), border tintado, status icon **filled** |
| `active` | En proceso | Bg `--paper`, border **1.5px** del color del estado, icon outlined |
| `available` | Disponible / actionable | Bg `--paper`, border `--line`, texto secundario `--ink-2` |
| `blocked` | Bloqueado / vacío | Bg `transparent`, border **dashed**, sin sombra, opacity 0.74, texto italic `--ink-3` |

**Hover:** `transform: translate(-1px, -1px)` + sombra `4px 4px 0 var(--ink)` + border solid `var(--ink)`.

### 3.6 Stat Tiles (KPI)

```css
.stat-tile {
  padding: 16px 18px;
  background: var(--paper);
  border: 1px solid var(--line);
  border-radius: 12px;
  box-shadow: 3px 3px 0 var(--line-soft);
  position: relative;
  overflow: hidden;
}
.stat-tile::after {
  content: "";
  position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
  background: var(--acc);  /* color del estado / acento */
}
```

Estructura: `label` (uppercase 10.5px `--ink-3`) → `value` (Fraunces 600 32px `--ink`) → `sub` (Manrope 12px `--ink-3`).

### 3.7 Progress Ring

SVG donut 92×92, stroke 8px. Track `--bg-2`, fill un linear-gradient `--st-promociona → --st-aprobado`. Centro: porcentaje Fraunces 600 18px. Ver `<ProgressRing>` en `app.jsx`.

### 3.8 Linear progress bar

```css
height: 6px;          /* o 4px para sub-progressbars */
background: var(--bg-2);          /* o --paper-3 */
border: 1px solid var(--line-soft);
border-radius: 999px;
overflow: hidden;

.bar-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--st-promociona), var(--st-aprobado));
  border-radius: 999px;
  transition: width 0.6s cubic-bezier(.2,.8,.2,1);
}
```

### 3.9 Code chip (mono badge)

```css
font: 600 10.5px "JetBrains Mono", monospace;
letter-spacing: 0.04em;
color: var(--ink-3);
background: var(--paper-3);
padding: 2px 8px;
border-radius: 6px;
border: 1px solid var(--line-soft);
```

Para códigos de materia, LU, IDs, hashes. **No para conteos numéricos grandes** — esos van en Fraunces.

### 3.10 Nota / grade pill

Badge tintado del color del acento contextual:

```css
font: 600 14px "Fraunces", serif;
color: var(--accent);
background: color-mix(in oklab, var(--accent) 16%, var(--paper));
border: 1px solid color-mix(in oklab, var(--accent) 32%, transparent);
padding: 1px 9px 2px;
border-radius: 8px;
```

### 3.11 Status icon (badge circular)

22×22 círculo con SVG 11×11 adentro. 4 variantes pintadas por `data-bucket="done|active|available|blocked"` — ver `.status-icon` en `styles.css`.

Glifos disponibles (`<StatusIcon>` en `app.jsx`):
- `done` → check
- `active` (INSCRIPTO) → dot
- `active` (A_FINAL) → exclamación
- `active` (RECURSA) → refresh
- `available` → libro / dos páginas
- `blocked` → candado

---

## 4. Layout patterns

### 4.1 Estructura general de página

```
.app (flex column, min-height 100%)
 ├── .topbar (sticky)
 ├── .stats-row    ── opcional: KPIs / contexto
 ├── .toolbar      ── filtros + búsqueda
 ├── .{main-area}  ── contenido principal (grilla, lista, detalle)
 └── .footer       ── leyenda + meta técnica
```

No todas las pantallas necesitan stats-row + toolbar. Pero **siempre** topbar + área principal + footer.

### 4.2 Grilla horizontal scrollable (tipo malla)

- Contenedor `overflow-x: auto`, padding `4px 32px 32px`.
- Hijo `display: flex; gap: 0; width: max-content`.
- Scrollbar custom 10px con thumb `--line-strong`.

### 4.3 Grilla 2 columnas con sub-headers

```
.{group}
 ├── .{group}-head     ── título + barra de progreso + count
 └── .{group}-cols     ── grid-template-columns: repeat(2, 232px) gap 12px
      ├── .subcol      ── header uppercase + cards en columna
      └── .subcol
```

Header de subcolumna: `border-bottom: 1px dashed var(--line)`.

### 4.4 Footer

Border-top `1px var(--line-soft)`, padding `14px 32px 18px`. Flex space-between con leyenda a la izquierda y meta JetBrains Mono a la derecha.

### 4.5 Breakpoints

```css
@media (max-width: 1200px) {
  .stats-row { grid-template-columns: 1fr; }
  .stats-tiles { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 720px) {
  .topbar { grid-template-columns: 1fr auto; padding: 14px 18px; }
  /* secciones: padding-left/right 18px */
  /* esconder info secundaria de topbar */
}
```

---

## 5. Interacciones

### 5.1 Hover sobre card "relacional"

Cuando una card tiene relaciones con otras (en el caso de la malla: correlativas), al hover:
- La card hovered: border `--ink`, shadow `4px 4px 0 --ink`, bg `--paper-2`.
- Las relacionadas "upstream" (prereqs): border `--st-afinal`, shadow tintada ámbar.
- Las relacionadas "downstream" (dependientes): border `--st-inscripto`, shadow tintada teal.
- El resto: `opacity: 0.32` (dim).

Patrón reutilizable: definir dos colores semánticos para las relaciones (ej ámbar para "depende de esto" y teal para "esto depende de").

### 5.2 Filtros

- Click en chip de estado → toggle (agregar/quitar del Set activo).
- "Todas" → limpia el Set.
- Las cards filtradas **no se ocultan**, se atenúan a `opacity: 0.18` (`data-faded="1"`).
- Esto preserva el layout y cualquier overlay (líneas SVG, etc).

### 5.3 Transiciones

- Default: `0.15s` ease, propiedades `transform, box-shadow, border-color, opacity, background`.
- Hover de card: `transform: translate(-1px, -1px)`.
- Progress bar: `width 0.6s cubic-bezier(.2,.8,.2,1)`.
- Respetar `prefers-reduced-motion`.

---

## 6. Iconografía

**Todo es SVG inline.** Sin librerías de iconos. Tamaños:
- Dentro de botones: 14×14.
- Dentro de status-icon (badge 22): 11×11.
- Brand mark: 18–22.
- Stroke width: 1.6 default, 2–2.4 para checks o iconos chicos donde la línea fina se pierde.
- `stroke-linecap: round`, `stroke-linejoin: round`.
- `fill="none"` por default (line-style), `fill="currentColor"` para glifos sólidos.

Si necesitás un icono nuevo, dibujalo simple sobre `viewBox="0 0 16 16"` y mantenelo line-style. Si fuera necesario, podés sumar Lucide o Phosphor manteniendo `stroke-width: 1.6` para que pegue con el resto.

---

## 7. Cómo armar una pantalla nueva — checklist

1. **Empezá del HTML base.** Copiá `Plan de Estudios.html` como template (cambia `<title>` y el `id` del root). Reusá `styles.css` tal cual — los tokens y componentes globales ya están.
2. **Topbar**: ajustá el sub-label (`PLAN DE ESTUDIOS` → tu pantalla) y el botón primary activo.
3. **Decidí el bucket layout**:
   - ¿Hay KPIs? → reutilizá `.stats-row` con `<ProgressRing>` + 4 `<StatTile>`.
   - ¿Hay filtros? → reutilizá `.toolbar` con `<FilterChips>` + search.
   - ¿Es grilla horizontal? → `.malla` + `.malla-inner`.
   - ¿Es lista vertical? → flex column con gap 10–12px, ancho máx 720–960px centrado.
   - ¿Es detail/form? → 2 columnas (`grid-template-columns: 1fr 320px`), main + sidebar.
4. **Cards / tiles**: usá las recetas de §3 con los `data-bucket` que correspondan al dominio.
5. **Estados**: mapeá tu dominio a los 4 buckets (`done/active/available/blocked`) o a alguno de los 7 status colors. Si no encaja, agregá un nuevo `--st-…` token.
6. **Footer**: leyenda + meta técnica (fecha de actualización, ID, etc).
7. **Validación final:**
   - ¿Usaste algún hex que no es token? → reemplazar.
   - ¿Hay `box-shadow` con blur? → eliminar.
   - ¿Hay border-radius >12px en cards? → bajar.
   - ¿Hay Inter / Roboto / system-ui visible? → mover a Manrope/Fraunces.
   - ¿Está todo en español? Sí.

---

## 8. Pantallas candidatas (roadmap)

Algunas pantallas que encajan en el lenguaje y se pueden construir reusando todo lo anterior:

- **Detalle de materia** (drawer/modal lateral): card grande con nombre Fraunces, code chip, status icon, correlativas listadas con mini-cards, profesores, comisiones, link al sistema legacy.
- **Lista de comisiones / inscripciones**: grilla vertical de cards con horarios mono, profesor, cupo, botón primary "Inscribirme".
- **Historial académico** (vista lista): tabla en cards con código + nombre + nota + fecha. Filtros por año.
- **Calendario de finales**: agenda semanal con cards posicionadas por día/hora.
- **Dashboard alumno (home)**: hero con progress ring grande + próximos finales + materias del cuatri actual + alertas (a final, recursa).
- **Settings / perfil**: form vertical en 2 columnas, labels uppercase, inputs pill 34px.
- **Login / onboarding**: card centrada 420px con form vertical, fondo `body` completo, brand mark grande arriba.

---

## 9. Referencia rápida

| Quiero… | Token / clase |
|---|---|
| Color de fondo de página | `var(--bg)` |
| Fondo de card | `var(--paper)` |
| Texto principal | `var(--ink)` |
| Texto secundario | `var(--ink-2)` |
| Metadata uppercase | `var(--ink-3)` + Manrope 700 10.5px letter-spacing 0.16em |
| Borde default | `1px solid var(--line)` |
| Sombra de card | `2px 2px 0 var(--line-soft)` |
| Sombra de hover | `4px 4px 0 var(--ink)` |
| Pill / chip / botón | `border-radius: 999px; height: 34px` |
| Card / tile | `border-radius: 12px` (o 10px en cards chicas) |
| Número grande | Fraunces 600, letter-spacing -0.02em |
| Código / hora / fecha | JetBrains Mono 500/600 |

Si dudás, abrí `Plan de Estudios.html` y mirá cómo está hecho — esa pantalla es la fuente de verdad visual.
